<?php

    $messages = [
        'connexion_success' => 'Connexion reuissi...',
        'deconnexion_succee' => 'Vous avez été déconnecté avec succès.'
    ];


    global $messages;